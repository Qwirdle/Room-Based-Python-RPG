class Player:
	def __init__()
	self.playerroom = playerroom
	self.inventory = inventory
	self.playerlanguages = playerlanguages
	self.playerspells = playerspells