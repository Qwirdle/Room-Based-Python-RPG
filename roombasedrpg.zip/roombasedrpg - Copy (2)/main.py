from collections import Counter
import random

gameloop = True
playermainactionselector = 'null'
playerroom = 'null'
playerinventory = []
playerlanguages = ['Common']
playerspells = ['Firebolt']
devmodeon = True

playermoveinput = 'null'
playerdevteleportroominput = 'null'
playeritemdropinput = 'null'
playeritempickupinput = 'null'
playeritemlookinput = 'null'
playeritemequipinput = 'null'
playeritemdequipinput = 'null'
playernpctalkinput = 'null'
playercombatselectinput = 'null'

playerincombat = False
playercombatinput = 'null'
playercombatspellinput = 'null'
combatturn = 'null'
playercombatrunawaychance = 0

combatnpcname = 'null'
combatnpcmaxhealth = 0
combatnpchealth = 0
combatnpcstrength = 0
combatnpcmana = 0
combatnpcstamina = 0


#List used to display inventory items more in a modular way
playerinventorydisplaycheck = []

#Player stats
playermaxhealth = 50
playerstrength = 30
playermaxmana = 50
playermana = 50
playerstamina = 50

playerhealth = playermaxhealth

#Player equipment stats
playerequipmenthealth = 0
playerequipmentstrength = 0
playerequipmentmana = 0
playerequipmentstamina = 0

#Player equipment slots
playerarmor_slot = 'null'
playeramulet1_slot = 'null'
playeramulet2_slot = 'null'

playerhandleft_slot = 'null'
playerhandright_slot = 'null'

playercarrying2handed = False


rooms = {}

rooms['devtest_room1'] = {

    'description': 'test',

    'room hostile': False,

    'exits': {
        'North': 'devtest_room2'
    },

    'items': ['Test Item'],

    'npcs': ['Human Peasent']

}

rooms['devtest_room2'] = {

    'description': 'test_',

    'room hostile': True,

    'exits': {
        'South': 'devtest_room1'
    },

    'items': [],

    'npcs': ['Human Peasent']

}

rooms['Darkwood Ghoul Nest Holding Cell'] = {

    'description': 'The room is made by Ghouls to hold their captured and future meals. The room has barely the necesitys a human needs to survive on lucky days. The room is littered with bones, mushrooms, muddy water and desecrated human corpses that are beyond recognition. The door seems to have bin carelessly unlocked.',

    'room hostile': False,

    'exits': {
        'North': 'Darkwood Ghoul Nest Cell Hall'
    },

    'items': ['Rusty Iron Sword'],

    'npcs': []

}

rooms['Darkwood Ghoul Nest Cell Hall'] = {

    'description': 'The hall has locked cells all around with corpses and bones and remains inside of them. You can smell the countless brutal and slow deaths that have occured in this lair. You can smell the iconic moist, damp and overwelmingly sour smell that is the main sign of Ghouls having lived here.',

    'room hostile': True,

    'exits': {
        'South': 'Darkwood Ghoul Nest Holding Cell',
        'West': 'Darkwood Ghoul Nest Feeding Area'
    },

    'items': [],

    'npcs': ['Ghoul Underling']

}

rooms['Darkwood Ghoul Nest Feeding Area'] = {

    'description': 'The room is large and in the shape of a dome. The floor is littered left and right with human remains. The Ghoul feeding area is the last thing many unlucky folk see.',

        'room hostile': True,

        'exits': {
            'East': 'Darkwood Ghoul Nest Cell Hall',
            'West': 'Darkwood Ghoul Nest Main Chambers'
        },

        'items': ['Hide Armor'],

        'npcs': ['Ghoul Underling', 'Ghoul Underling']

}

rooms['Darkwood Ghoul Nest Main Chambers'] = {

    'description': 'The main room of a Ghoulic group is where the leader resides. Very few people ever step foot in here and less live to tell the tale.',

    'room hostile': True,

    'exits': {
        'East': 'Darkwood Ghoul Nest Feeding Area',
        'North': 'Darkwood Ghoul Outer Clearing'
    },

    'items': [],

    'npcs': ['Ghoul Menace']

}

rooms['Darkwood Ghoul Outer Clearing'] = {

    'description': 'Compared to the dark and horrifying Ghoul Nest within the cave to your south the outside world feels like heaven. You can see animals grazing, flowers, trees and the wonders of nature all around.',

    'room hostile': False,

    'exits': {
        'South': 'Darkwood Ghoul Nest Main Chambers'
    },

    'items': [],

    'npcs': []

}

items = {}

items['Test Item'] = {

    'item_type': 'misc',

    'description': 'test'

}

items['Ghoulic Plasma'] = {

    'item_type': 'misc',

    'description': 'Ghoulic Plasma is the remains of the wretched and cursed ghouls that terrorize the night.'

}

items['Hide Armor'] = {

    'item_type': 'armor',

    'description': 'Hide armor is light and allows the bearer of the armor to move around during combat quickly and maintain a basic level of protection.',

    'health_bonus': 30,

    'strength_bonus': 10,

    'mana_bonus': 0,

    'stamina_bonus': 20

}

items['Rusty Iron Sword'] = {

    'item_type': '1handweapon',

    'description': "Its obviusly an older and not cared for weapon but in a pinch it will do.",

    'health_bonus': 10,

    'strength_bonus': 10,

    'mana_bonus': 0,

    'stamina_bonus': 20

}

items['Weighted Steel Warhammer'] = {

    'item_type': '1handweapon',

    'description': 'Weighted warhammers are weighted at the sides of the hammer to bring down unhealing force on a target. They sacerfice movement for force and with the stell backing this weapon up nothing can stop its skull crushing fall.',

    'health_bonus': 10,

    'strength_bonus': 80,

    'mana_bonus': 0,

    'stamina_bonus': -30

}

items['Wizard Students Amulet'] = {

    'item_type': 'amulet',

    'description': 'test_',

    'health_bonus': 10,

    'strength_bonus': 20,

    'mana_bonus': 20,

    'stamina_bonus': 0

}

npcs = {}

npcs['Human Peasent'] = {

    'type': 'Generic',

    'interact_dialouge': ['Do you have spare change?', 'Leave me alone...', '*cough*', 'What are you doing in this part of town?'],

    'faction': 'null',

    'spoken_languages': ['Common', 'Under Talk'],

    'health': 70,

    'strength': 30,

    'mana': 50,

    'stamina': 40,

    'inventory': ['Test Item']

}

npcs['Ghoul Underling'] = {

    'type': 'Monster',

    'faction': 'null',

    'health': 30,

    'strength': 20,

    'mana': 0,

    'stamina': 10,

    'inventory': ['Ghoulic Plasma']

}

npcs['Ghoul Menace'] = {

    'type': 'Monster',

    'faction': 'null',

    'health': 80,

    'strength': 30,

    'mana': 20,

    'stamina': 40,

    'inventory': ['Ghoulic Plasma', 'Ghoulic Plasma', 'Ghoulic Plasma']

}

spells = {}

spells['Firebolt'] = {

    'type': 'Combat',

    'damage': 20,

    'mana cost': 30,

    'description': "You shoot out a bolt of fire seemingly from your hands at a designated target."

}



playerroom = 'Darkwood Ghoul Nest Holding Cell'

print('You awaken in a holding cell. You have a blurry memory but the last thing you can remember is that you were camping through the night in the wilderness and you got jumped and captured by ghouls. You should look around and see if you can find somethings to help you escape as there is nothing else to do but wait for the ghouls to eat you alive. You see a glint of a weapon on the floor and the door looks a bit off.')

while (gameloop == True):

    playermainactionselector = input(f'> ')

    #Player room to room movement
    if (playermainactionselector == 'Move'):
        if rooms[playerroom]['room hostile'] == False:
            #Gives the player a list of available movement options
            print(f'You can move in these {len(rooms[(playerroom)]["exits"])} directions: ')
            for item in (rooms[(playerroom)]["exits"].keys()):
                print(f'{item}: {rooms[(playerroom)]["exits"][item]}')

            playermoveinput = input('In what direction would you like to move in?')

            if (playermoveinput in rooms[(playerroom)]["exits"].keys()):
                #If the room the player wants to enter is available move the player to said room
                playerroom = rooms[(playerroom)]["exits"][playermoveinput]

                print(f'You are now in {playerroom}')
            else:
                print(f'{playermoveinput} is not a valid direction')
        else:
            print(f"The room is hostile and there are still enemys in the room. You can't leave the room unless you have cleared it.")

    #Player looks around room
    elif playermainactionselector == 'Look':
        print(f'You are in {playerroom}')
        print(rooms[playerroom]['description'])
        print(f'Exits:')
        for item in (rooms[playerroom]["exits"].keys()):
            print(f'{item}: {rooms[playerroom]["exits"][item]}')
        print(f'Items:')
        playerinventorydisplaycheck = []
        for item in (rooms[playerroom]['items']):
            if item not in playerinventorydisplaycheck:
                print(f'{item}({rooms[playerroom]["items"].count(item)})')
                playerinventorydisplaycheck.append(item)
        print(f"NPC's:")
        for item in (rooms[playerroom]['npcs']):
            print(item)

    #Gives list of commands
    elif playermainactionselector == 'Help':
        print('Help Guide:')

    elif playermainactionselector == 'Inventory':
        playerinventorydisplaycheck = []
        for item in playerinventory:
            if item not in playerinventorydisplaycheck:
                print(f'{item}({playerinventory.count(item)})')
                playerinventorydisplaycheck.append(item)

    #Drops items on the ground
    elif playermainactionselector == 'Drop':
        if len(playerinventory) > 0:
            print('Which of the following items do you wish to drop?')
            playerinventorydisplaycheck = []
            for item in playerinventory:
                if item not in playerinventorydisplaycheck:
                    print(f'{item}({playerinventory.count(item)})')
                    playerinventorydisplaycheck.append(item)
            playeritemdropinput = input(f'> ')

            if playeritemdropinput in playerinventory:
                playerinventory.remove(playeritemdropinput)
                rooms[playerroom]["items"].append(playeritemdropinput)
                print(f'You dropped {playeritemdropinput}.')
            else:
                print('Invalid Item')

        else:
            print('You have no items in your inventory')

    #Player talks with NPC in room
    elif playermainactionselector == 'Talk':
        if len(rooms[playerroom]['npcs']) > 0:
            print('What npc would you like to talk to?')
            for item in (rooms[playerroom]['npcs']):
                print(item)
            playernpctalkinput = input(f'> ')

            if playernpctalkinput in rooms[playerroom]['npcs']:
                if npcs[playernpctalkinput]['type'] == 'Generic':
                    if any(elem in playerlanguages for elem in npcs[playernpctalkinput]['spoken_languages']):
                        print(f'{playernpctalkinput}: {npcs[playernpctalkinput]["interact_dialouge"][random.randint(0, len(npcs[playernpctalkinput]["interact_dialouge"]) - 1)]}')
                    else:
                        print("You don't understand what they are saying as it is in another language.")
                        print("You guess they are probally speaking one of the following languages:")
                        for item in (npcs[playernpctalkinput]['spoken_languages']):
                            print(item)
                if npcs[playernpctalkinput]['type'] == 'Monster':
                    print(f"{playernpctalkinput} is a monster and cannot be reasonably communicated with.")

            else:
                print(f"This npc isn't in the room or can't be talked to.")
        else:
            print('There are no npcs nearby to talk with.')

    #The player rests to heal their stats.
    elif playermainactionselector == 'Rest':
        if rooms[playerroom]['room hostile'] == False:
            print('You rest and your stats restore.')
            playerhealth = playermaxhealth + playerequipmenthealth
            playermana = playermaxmana + playerequipmentmana
        else:
            print('The room is unsafe to rest in. Kill all enemys in the room to be able to rest.')

    elif playermainactionselector == 'Fight':
        if len(rooms[playerroom]['npcs']) > 0:
            print(f'What npc would you like to fight?')
            for item in (rooms[playerroom]['npcs']):
                print(item)
            playercombatselectinput = input('> ')

            if playercombatselectinput in rooms[playerroom]['npcs']:
                print(f"You enter combat with {playercombatselectinput}!")
                combatnpcname = playercombatselectinput
                combatnpchealth = npcs[playercombatselectinput]['health']
                combatnpchp = npcs[playercombatselectinput]['health']
                combatnpcstrength = npcs[playercombatselectinput]['strength']
                combatnpcmana = npcs[playercombatselectinput]['mana']
                combatnpcstamina = npcs[playercombatselectinput]['stamina']



                if devmodeon == True:
                    print('NPC Stats:')
                    print(f"Name: {combatnpcname}")
                    print(f"Max Health: {combatnpchealth}")
                    print(f"Health: {combatnpchp}")
                    print(f"Strength: {combatnpcstrength}")
                    print(f"Mana: {combatnpcmana}")
                    print(f"Stamina: {combatnpcstamina}")

                playerincombat = True
                playermana = playermaxmana + playerequipmentmana

                if playerstamina >= combatnpcstamina:
                    combatturn = 'Player'
                else:
                    combatturn = 'NPC'

                while playerincombat == True:

                    if combatturn == 'Player':
                        while combatturn == 'Player':
                            print(f'Player Health: {playerhealth}/{playermaxhealth + playerequipmenthealth}')
                            print(f'Player Mana: {playermaxmana}')
                            print(f'What would you like to do?')
                            print(f'1) Attack')
                            print(f'2) Cast Spell')
                            print(f'3) Run Away')

                            playercombatinput = input('> ')

                            if playercombatinput == 'Attack':
                                print(f"You attack {combatnpcname} for {(playerstrength / 2)} damage!")
                                combatnpchp = combatnpchp - (playerstrength / 2)
                                combatturn = 'NPC'

                            if playercombatinput == 'Cast Spell':
                                print(f'What spell would you like to cast?')
                                for item in playerspells:
                                    print(f"{item} for {spells[item]['mana cost']} mana")
                                playercombatspellinput = input('> ')
                                if playercombatspellinput in playerspells:
                                    if spells[playercombatspellinput]['type'] == 'Combat':
                                        if playermaxmana >= spells[playercombatspellinput]['mana cost']:
                                            print(f"You cast {playercombatspellinput} and it hits {combatnpcname} for {spells[playercombatspellinput]['damage']} damage!")
                                            combatnpchp = combatnpchp - spells[playercombatspellinput]['damage']
                                            playermaxmana = playermaxmana - spells[playercombatspellinput]['mana cost']
                                            combatturn = 'NPC'
                                        else:
                                            print(f"You don't have enough mana to cast this spell.")
                                    else:
                                        print("This spell cant be casted during combat")
                                else:
                                    print(f"You either don't have this spell or it doesn't exist.")

                            if playercombatinput == 'Run Away':
                                playercombatrunawaychance = random.randint(1, 3)
                                if playercombatrunawaychance == 1:
                                    print('You run away!')
                                    playerincombat = False
                                    break
                                else:
                                    print('You fail to run away.')
                                    combatturn = 'NPC'

                    if playerhealth < 1:
                        print('The player dies!')
                        break
                    elif combatnpchp < 1:
                        print(f'{combatnpcname} dies!')
                        rooms[playerroom]['npcs'].pop(rooms[playerroom]['npcs'].index(playercombatselectinput))
                        for item in npcs[playercombatselectinput]['inventory']:
                            rooms[playerroom]['items'].append(item)
                        if not rooms[playerroom]['npcs']:
                            if rooms[playerroom]['room hostile'] == True:
                                rooms[playerroom]['room hostile'] = False
                        break

                    if combatturn == 'NPC':
                        print(f'{combatnpcname} Health: {combatnpchp}/{combatnpchealth}')
                        print(f'{combatnpcname} attacks you for {(combatnpcstrength / 2)} damage!')
                        playerhealth = playerhealth - (combatnpcstrength / 2)
                        combatturn = 'Player'

                    if playerhealth < 1:
                        print('The player dies!')
                        break
                    elif combatnpchp < 1:
                        print(f'{combatnpcname} dies!')
                        rooms[playerroom]['npcs'].pop(rooms[playerroom]['npcs'].index(playercombatselectinput))
                        for item in npcs[playercombatselectinput]['inventory']:
                            rooms[playerroom]['items'].append(item)
                        if not rooms[playerroom]['npcs']:
                            if rooms[playerroom]['room hostile'] == True:
                                rooms[playerroom]['room hostile'] = False
                        break



            else:
                print("The npc isn't in this room or it can't be fought.")

        else:
            print(f"There are no npcs in the room to fight.")


    #Player picks up items from the ground into their inventory
    elif playermainactionselector == 'Pickup':
        if len(rooms[playerroom]["items"]) > 0:
            print(f'What item would you like to pickup?')
            playerinventorydisplaycheck = []
            for item in (rooms[playerroom]['items']):
                if item not in playerinventorydisplaycheck:
                    print(f'{item}({rooms[playerroom]["items"].count(item)})')
                    playerinventorydisplaycheck.append(item)
            playeritempickupinput = input(f'> ')

            if playeritempickupinput in rooms[(playerroom)]["items"]:
                rooms[(playerroom)]["items"].remove(playeritempickupinput)
                playerinventory.append(playeritempickupinput)
                print(f'You pickuped {playeritempickupinput}.')
            else:
                print('Item isnt on the ground.')

        else:
            print('There are no items to pickup')

        if playeritempickupinput in rooms[(playerroom)]["items"]:
            print('Temp')

    #Player reads description of an item in their inventory
    elif playermainactionselector == 'Inspect':
        if (len(playerinventory) > 0):
            print(f'What item do you want to look at?')
            playerinventorydisplaycheck = []
            for item in (playerinventory):
                if item not in playerinventorydisplaycheck:
                    print(f'{item}({playerinventory.count(item)})')
                    playerinventorydisplaycheck.append(item)
            playeritemlookinput = input('> ')

            if playeritemlookinput in playerinventory:
                if items[playeritemlookinput]["item_type"] == 'misc':
                    print(f'{items[playeritemlookinput]["description"]}')
                    print(f'Item type: {items[playeritemlookinput]["item_type"]}')

                if (items[playeritemlookinput]["item_type"] == 'armor'):
                    print(f'{items[playeritemlookinput]["description"]}')
                    print(f'Item type: {items[playeritemlookinput]["item_type"]}')
                    print(f'Health bonus: {items[playeritemlookinput]["health_bonus"]}')
                    print(f'Strength bonus: {items[playeritemlookinput]["strength_bonus"]}')
                    print(f'Mana bonus: {items[playeritemlookinput]["mana_bonus"]}')
                    print(f'Stamina bonus: {items[playeritemlookinput]["stamina_bonus"]}')

                if (items[playeritemlookinput]["item_type"] == 'amulet'):
                    print(f'{items[playeritemlookinput]["description"]}')
                    print(f'Item type: {items[playeritemlookinput]["item_type"]}')
                    print(f'Health bonus: {items[playeritemlookinput]["health_bonus"]}')
                    print(f'Strength bonus: {items[playeritemlookinput]["strength_bonus"]}')
                    print(f'Mana bonus: {items[playeritemlookinput]["mana_bonus"]}')
                    print(f'Stamina bonus: {items[playeritemlookinput]["stamina_bonus"]}')

                if (items[playeritemlookinput]["item_type"] == '1handweapon'):
                    print(f'{items[playeritemlookinput]["description"]}')
                    print(f'Item type: {items[playeritemlookinput]["item_type"]}')
                    print(f'Health bonus: {items[playeritemlookinput]["health_bonus"]}')
                    print(f'Strength bonus: {items[playeritemlookinput]["strength_bonus"]}')
                    print(f'Mana bonus: {items[playeritemlookinput]["mana_bonus"]}')
                    print(f'Stamina bonus: {items[playeritemlookinput]["stamina_bonus"]}')

                if (items[playeritemlookinput]["item_type"] == '2handweapon'):
                    print(f'{items[playeritemlookinput]["description"]}')
                    print(f'Item type: {items[playeritemlookinput]["item_type"]}')
                    print(f'Health bonus: {items[playeritemlookinput]["health_bonus"]}')
                    print(f'Strength bonus: {items[playeritemlookinput]["strength_bonus"]}')
                    print(f'Mana bonus: {items[playeritemlookinput]["mana_bonus"]}')
                    print(f'Stamina bonus: {items[playeritemlookinput]["stamina_bonus"]}')
            else:
                print("You don't have this item.")

    #Show player equipment
    elif playermainactionselector == 'Equipment':
        print(f'Armor: {playerarmor_slot}')
        print(f'Amulet: {playeramulet1_slot}')
        print('')

        if playercarrying2handed == False:
            print(f'Left hand: {playerhandleft_slot}')
            print(f'Right hand: {playerhandright_slot}')

        else:
            print(f'Both hands: {playerhandleft_slot}')

    #Check player statistics
    elif playermainactionselector == 'Stats':
        print(f'Player Health: {playerhealth}/{playermaxhealth + playerequipmenthealth}')
        print(f'Player Strength: {playerstrength + playerequipmentstrength}')
        print(f'Player Mana: {playermana + playerequipmentmana}')
        print(f'Player Stamina: {playerstamina + playerequipmentstamina}')

    #Equiping an item from the players inventory
    elif playermainactionselector == 'Equip':
        print('What item would you like to equip?')
        playerinventorydisplaycheck = []
        for item in playerinventory:
            if item not in playerinventorydisplaycheck:
                print(f'{item}({playerinventory.count(item)})')
                playerinventorydisplaycheck.append(item)
        playeritemequipinput = input('> ')

        if (playeritemequipinput in playerinventory and playeritemequipinput in items):
            if items[playeritemequipinput]['item_type'] == 'armor' or items[playeritemequipinput]['item_type'] == 'amulet' or items[playeritemequipinput]['item_type'] =='1handweapon' or  items[playeritemequipinput]['item_type'] =='2handweapon':
                if items[playeritemequipinput]["item_type"] == 'armor':

                    if playerarmor_slot == 'null':
                        playerarmor_slot = playeritemequipinput
                        print(f'You equiped {playeritemequipinput}.')
                        playerequipmenthealth += items[playeritemequipinput]['health_bonus']
                        playerequipmentstrength += items[playeritemequipinput]['strength_bonus']
                        playerequipmentmana += items[playeritemequipinput]['mana_bonus']
                        playerequipmentstamina += items[playeritemequipinput]['stamina_bonus']
                    else:
                        print('There is already equipment in this slot.')

                elif items[playeritemequipinput]["item_type"] == 'amulet':

                    if playeramulet1_slot == 'null':
                        playeramulet1_slot = playeritemequipinput
                        print(f'You equiped {playeritemequipinput}.')
                        playerequipmenthealth += items[playeritemequipinput]['health_bonus']
                        playerequipmentstrength += items[playeritemequipinput]['strength_bonus']
                        playerequipmentmana += items[playeritemequipinput]['mana_bonus']
                        playerequipmentstamina += items[playeritemequipinput]['stamina_bonus']
                    else:
                        print('There is already equipment in this slot.')

                elif items[playeritemequipinput]["item_type"] == '1handweapon':

                    if playerhandleft_slot == 'null':
                        playerhandleft_slot = playeritemequipinput
                        print(f'You equiped {playeritemequipinput}.')
                        playerequipmenthealth += items[playeritemequipinput]['health_bonus']
                        playerequipmentstrength += items[playeritemequipinput]['strength_bonus']
                        playerequipmentmana += items[playeritemequipinput]['mana_bonus']
                        playerequipmentstamina += items[playeritemequipinput]['stamina_bonus']
                    else:
                        print('There is already equipment in this slot.')

                elif items[playeritemequipinput]["item_type"] == '2handweapon':

                    if playerhandright_slot == 'null':
                        playerhandright_slot = playeritemequipinput
                        print(f'You equiped {playeritemequipinput}.')
                        playerequipmenthealth += items[playeritemequipinput]['health_bonus']
                        playerequipmentstrength += items[playeritemequipinput]['strength_bonus']
                        playerequipmentmana += items[playeritemequipinput]['mana_bonus']
                        playerequipmentstamina += items[playeritemequipinput]['stamina_bonus']
                    else:
                        print('There is already equipment in this slot.')

            else:
                print("This item can't be equiped.")
        else:
            print("You dont have this item.")

    #Player dequips Equipment
    elif playermainactionselector == 'Dequip':
        print('What would you like to dequip?')
        print(f'Armor: {playerarmor_slot}')
        print(f'Amulet: {playeramulet1_slot}')
        print('')

        if playercarrying2handed == False:
            print(f'Left hand: {playerhandleft_slot}')
            print(f'Right hand: {playerhandright_slot}')

        else:
            print(f'Both hands: {playerhandleft_slot}')

        playeritemdequipinput = input('> ')

        if playeritemdequipinput == playerarmor_slot or playeritemdequipinput == playeramulet1_slot or playeritemdequipinput == playerhandleft_slot or playeritemdequipinput == playerhandright_slot:
            if playeritemdequipinput in items:
                if items[playeritemdequipinput]["item_type"] == 'armor':
                    playerarmor_slot = 'Null'
                    playerequipmenthealth -= items[playeritemdequipinput]['health_bonus']
                    playerequipmentstrength -= items[playeritemdequipinput]['strength_bonus']
                    playerequipmentmana -= items[playeritemdequipinput]['mana_bonus']
                    playerequipmentstamina -= items[playeritemdequipinput]['stamina_bonus']
                    print(f'You dequiped {playeritemdequipinput}')

                if items[playeritemdequipinput]["item_type"] == 'amulet':
                    playerarmor_slot = 'Null'
                    playerequipmenthealth -= items[playeritemdequipinput]['health_bonus']
                    playerequipmentstrength -= items[playeritemdequipinput]['strength_bonus']
                    playerequipmentmana -= items[playeritemdequipinput]['mana_bonus']
                    playerequipmentstamina -= items[playeritemdequipinput]['stamina_bonus']
                    print(f'You dequiped {playeritemdequipinput}')

                if items[playeritemdequipinput]["item_type"] == '1handweapon':
                    playerarmor_slot = 'Null'
                    playerequipmenthealth -= items[playeritemdequipinput]['health_bonus']
                    playerequipmentstrength -= items[playeritemdequipinput]['strength_bonus']
                    playerequipmentmana -= items[playeritemdequipinput]['mana_bonus']
                    playerequipmentstamina -= items[playeritemdequipinput]['stamina_bonus']
                    print(f'You dequiped {playeritemdequipinput}')

                if items[playeritemdequipinput]["item_type"] == '2handweapon':
                    playerarmor_slot = 'Null'
                    playerequipmenthealth -= items[playeritemdequipinput]['health_bonus']
                    playerequipmentstrength -= items[playeritemdequipinput]['strength_bonus']
                    playerequipmentmana -= items[playeritemdequipinput]['mana_bonus']
                    playerequipmentstamina -= items[playeritemdequipinput]['stamina_bonus']
                    print(f'You dequiped {playeritemdequipinput}')

            else:
                print("This item doesn't exist.")

        else:
            print("You don't have this item dequiped or this item doesn't exist.")

    #Dev/Debug command to teleport player to room of chosing
    elif devmodeon == True and playermainactionselector == 'Debug_Teleport':
        playerdevteleportroominput = input('What room would you like to teleport to?')

        if playerdevteleportroominput in rooms:
            playerroom = playerdevteleportroominput
            print(f'You are now in {playerroom}.')

        else:
            print(f'{playerdevteleportroominput} is not a valid room')

    #Dev/Debug command to list all rooms and their respective exits
    elif devmodeon == True and playermainactionselector == 'Debug_ListRooms':
        for item in (rooms.keys()):
            print(f'{item} / {rooms[item]["exits"]}')

